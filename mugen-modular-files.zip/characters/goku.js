export const goku = {
  id: 'goku',
  name: 'GOKU',
  palette: {
    outline: '#16120f', skin: '#e9a06f', skinShadow: '#b96848',
    main: '#e8751a', shadow: '#9d3f0e', accent: '#163b9b', hair: '#0a0c12', energy: '#6de8ff'
  },
  stats: { life: 1000, power: 0, walk: 2.35, backWalk: 2.0, jump: -8.4, gravity: 0.43 },
  moves: {
    x: { state: 200, anim: 'jab', damage: 34, guardDamage: 4, hitstun: 13, guardstun: 9, push: 3.2, startup: 3, active: 2, recovery: 8 },
    y: { state: 210, anim: 'strongPunch', damage: 62, guardDamage: 8, hitstun: 18, guardstun: 12, push: 5.2, launch: -1.5, startup: 6, active: 3, recovery: 13 },
    a: { state: 230, anim: 'lowKick', damage: 42, guardDamage: 5, hitstun: 14, guardstun: 10, push: 3.7, startup: 4, active: 3, recovery: 10 },
    b: { state: 240, anim: 'roundhouse', damage: 75, guardDamage: 9, hitstun: 22, guardstun: 14, push: 6.2, launch: -2.8, startup: 8, active: 4, recovery: 16 },
    z: { state: 1000, anim: 'kiBlast', projectile: true, damage: 48, guardDamage: 7, hitstun: 16, guardstun: 11, push: 4.4, startup: 9, active: 1, recovery: 15, powerGain: 60 },
    c: { state: 1100, anim: 'beam', projectile: true, beam: true, damage: 135, guardDamage: 20, hitstun: 30, guardstun: 20, push: 8.0, startup: 24, active: 1, recovery: 28, powerCost: 500 }
  },
  animations: {
    idle: [8,8,8,8], walk: [5,5,5,5], crouch:[1], jump:[1], fall:[1], guard:[1], hit:[4,4], ko:[1],
    jab:[3,2,8], strongPunch:[6,3,13], lowKick:[4,3,10], roundhouse:[8,4,16], kiBlast:[9,1,15], beam:[12,12,1,28]
  },
  boxes: {
    standHurt: [{x:-12,y:-72,w:24,h:68}], crouchHurt:[{x:-14,y:-48,w:28,h:44}],
    jab:[{frame:1,x:8,y:-58,w:27,h:13}], strongPunch:[{frame:1,x:10,y:-57,w:38,h:18}],
    lowKick:[{frame:1,x:6,y:-30,w:34,h:14}], roundhouse:[{frame:1,x:8,y:-50,w:48,h:17}]
  },
  draw(ctx, fighter, frameIndex) {
    drawSaiyan(ctx, fighter, frameIndex, this.palette, 'goku');
  }
};

function px(ctx,x,y,w,h,fill,outline){
  ctx.fillStyle=outline; ctx.fillRect(x-1,y-1,w+2,h+2); ctx.fillStyle=fill; ctx.fillRect(x,y,w,h);
}
function poly(ctx,pts,fill,outline){
  ctx.fillStyle=outline; ctx.beginPath(); ctx.moveTo(pts[0][0],pts[0][1]); for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.translate(0,1); ctx.scale(.96,.96); ctx.fillStyle=fill; ctx.beginPath(); ctx.moveTo(pts[0][0],pts[0][1]); for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]); ctx.closePath(); ctx.fill(); ctx.restore();
}
function drawSaiyan(ctx,f,frame,p,type){
  const t=f.animTick; const idle=Math.sin(t*.12)*1.2; let lean=0, crouch=0, arm=0,kick=0;
  if(f.state===20) arm=Math.sin(t*.5)*5;
  if(f.state===11) crouch=18;
  if(f.state===200) arm=frame===1?20:8;
  if(f.state===210) arm=frame===1?30:10;
  if(f.state===230) kick=frame===1?22:7;
  if(f.state===240) kick=frame===1?34:10;
  if(f.state>=5000) lean=-10;
  ctx.save(); ctx.translate(Math.round(f.x),Math.round(f.y+idle+crouch)); ctx.scale(f.facing,1); ctx.rotate(lean*Math.PI/180);
  ctx.imageSmoothingEnabled=false;
  // back leg
  px(ctx,-12,-28,10,27,p.shadow,p.outline); px(ctx,-13,-4,14,7,p.accent,p.outline);
  // back arm
  px(ctx,-15,-60,8,28,p.skinShadow,p.outline); px(ctx,-17,-35,11,7,p.accent,p.outline);
  // torso and gi
  poly(ctx,[[-17,-64],[0,-72],[17,-64],[14,-31],[-14,-31]],p.main,p.outline);
  px(ctx,-15,-38,30,6,p.accent,p.outline);
  poly(ctx,[[-12,-62],[0,-50],[12,-62],[7,-68],[-7,-68]],p.accent,p.outline);
  // front leg / kick
  const fx=kick;
  px(ctx,3+fx,-29,10,28,p.main,p.outline); px(ctx,2+fx,-4,15,7,p.accent,p.outline);
  // front arm
  const ax=arm;
  px(ctx,8+ax,-60,9,29,p.skin,p.outline); px(ctx,7+ax,-35,12,7,p.accent,p.outline);
  // neck/head
  px(ctx,-5,-78,10,12,p.skin,p.outline); px(ctx,-11,-94,22,20,p.skin,p.outline);
  // hair spikes
  poly(ctx,[[-12,-91],[-21,-103],[-12,-101],[-17,-116],[-6,-105],[-5,-122],[2,-106],[9,-121],[9,-104],[20,-114],[14,-98],[23,-100],[12,-89]],p.hair,p.outline);
  // face
  ctx.fillStyle='#111'; ctx.fillRect(5,-88,2,2); ctx.fillRect(2,-84,7,1);
  // gi symbol
  ctx.fillStyle='#f4efe5'; ctx.fillRect(-14,-53,6,6); ctx.fillStyle='#111'; ctx.fillRect(-12,-51,2,2);
  // energy charge
  if(f.state===1000||f.state===1100){
    ctx.globalAlpha=.9; ctx.fillStyle=p.energy; const r=f.state===1100?9:5; ctx.beginPath(); ctx.arc(24+arm,-47,r,0,Math.PI*2); ctx.fill(); ctx.globalAlpha=1;
  }
  ctx.restore();
}
