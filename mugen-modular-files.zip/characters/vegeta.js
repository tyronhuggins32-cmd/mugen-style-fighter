export const vegeta = {
  id: 'vegeta',
  name: 'VEGETA',
  palette: {
    outline:'#10131d', skin:'#e5a06d', skinShadow:'#b86b48',
    main:'#1830a0', shadow:'#101b63', accent:'#f3f5ff', gold:'#d7a430', hair:'#090b10', energy:'#c560ff'
  },
  stats: { life: 1000, power: 0, walk: 2.25, backWalk: 2.05, jump: -8.1, gravity: 0.44 },
  moves: {
    x: { state: 200, anim: 'jab', damage: 36, guardDamage: 4, hitstun: 13, guardstun: 9, push: 3.3, startup: 3, active: 2, recovery: 8 },
    y: { state: 210, anim: 'elbow', damage: 65, guardDamage: 8, hitstun: 19, guardstun: 13, push: 5.5, launch: -1.3, startup: 6, active: 3, recovery: 13 },
    a: { state: 230, anim: 'knee', damage: 44, guardDamage: 5, hitstun: 14, guardstun: 10, push: 3.8, startup: 4, active: 3, recovery: 10 },
    b: { state: 240, anim: 'axeKick', damage: 78, guardDamage: 10, hitstun: 23, guardstun: 15, push: 6.4, launch: -3.0, startup: 9, active: 4, recovery: 16 },
    z: { state: 1000, anim: 'kiBlast', projectile: true, damage: 52, guardDamage: 7, hitstun: 17, guardstun: 11, push: 4.7, startup: 8, active: 1, recovery: 15, powerGain: 60 },
    c: { state: 1100, anim: 'beam', projectile: true, beam: true, damage: 140, guardDamage: 22, hitstun: 31, guardstun: 21, push: 8.2, startup: 22, active: 1, recovery: 29, powerCost: 500 }
  },
  animations: {
    idle:[8,8,8,8], walk:[5,5,5,5], crouch:[1], jump:[1], fall:[1], guard:[1], hit:[4,4], ko:[1],
    jab:[3,2,8], elbow:[6,3,13], knee:[4,3,10], axeKick:[9,4,16], kiBlast:[8,1,15], beam:[11,11,1,29]
  },
  boxes: {
    standHurt:[{x:-12,y:-70,w:24,h:66}], crouchHurt:[{x:-14,y:-47,w:28,h:43}],
    jab:[{frame:1,x:8,y:-57,w:27,h:13}], elbow:[{frame:1,x:8,y:-55,w:34,h:18}],
    knee:[{frame:1,x:5,y:-34,w:29,h:16}], axeKick:[{frame:1,x:7,y:-53,w:47,h:19}]
  },
  draw(ctx,fighter,frameIndex){ drawVegeta(ctx,fighter,frameIndex,this.palette); }
};

function px(ctx,x,y,w,h,fill,outline){ctx.fillStyle=outline;ctx.fillRect(x-1,y-1,w+2,h+2);ctx.fillStyle=fill;ctx.fillRect(x,y,w,h);}
function poly(ctx,pts,fill,outline){ctx.fillStyle=outline;ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.closePath();ctx.fill();ctx.save();ctx.translate(0,1);ctx.scale(.96,.96);ctx.fillStyle=fill;ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.closePath();ctx.fill();ctx.restore();}
function drawVegeta(ctx,f,frame,p){
  const t=f.animTick; const idle=Math.sin(t*.13)*1.1; let crouch=0,arm=0,kick=0,lean=0;
  if(f.state===20)arm=Math.sin(t*.5)*5;if(f.state===11)crouch=18;if(f.state===200)arm=frame===1?20:8;if(f.state===210)arm=frame===1?27:9;if(f.state===230)kick=frame===1?19:6;if(f.state===240)kick=frame===1?33:9;if(f.state>=5000)lean=-10;
  ctx.save();ctx.translate(Math.round(f.x),Math.round(f.y+idle+crouch));ctx.scale(f.facing,1);ctx.rotate(lean*Math.PI/180);ctx.imageSmoothingEnabled=false;
  px(ctx,-12,-28,10,27,p.shadow,p.outline);px(ctx,-13,-4,14,8,p.accent,p.outline);
  px(ctx,-15,-60,8,28,p.shadow,p.outline);px(ctx,-17,-35,11,8,p.accent,p.outline);
  poly(ctx,[[-17,-64],[0,-70],[17,-64],[14,-31],[-14,-31]],p.main,p.outline);
  poly(ctx,[[-19,-64],[-12,-70],[12,-70],[19,-64],[14,-43],[-14,-43]],p.accent,p.outline);
  px(ctx,-10,-56,20,7,p.gold,p.outline);px(ctx,-9,-47,18,5,p.gold,p.outline);
  const fx=kick;px(ctx,3+fx,-29,10,28,p.main,p.outline);px(ctx,2+fx,-4,15,8,p.accent,p.outline);
  const ax=arm;px(ctx,8+ax,-60,9,29,p.main,p.outline);px(ctx,7+ax,-35,12,8,p.accent,p.outline);
  px(ctx,-5,-78,10,12,p.skin,p.outline);px(ctx,-11,-94,22,20,p.skin,p.outline);
  // tall hair and widow's peak
  poly(ctx,[[-12,-91],[-19,-105],[-12,-103],[-14,-120],[-6,-108],[-3,-128],[2,-109],[8,-129],[9,-107],[18,-120],[14,-102],[23,-108],[13,-89]],p.hair,p.outline);
  poly(ctx,[[-6,-94],[0,-88],[6,-94],[4,-90],[0,-86],[-4,-90]],p.hair,p.outline);
  ctx.fillStyle='#111';ctx.fillRect(5,-88,2,2);ctx.fillRect(2,-84,7,1);
  if(f.state===1000||f.state===1100){ctx.globalAlpha=.9;ctx.fillStyle=p.energy;const r=f.state===1100?9:5;ctx.beginPath();ctx.arc(24+arm,-47,r,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
  ctx.restore();
}
