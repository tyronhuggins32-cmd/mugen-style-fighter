# Modular MUGEN-style Browser Fighter

This project uses one engine/stage file and separate character modules.

## File layout

```text
index.html
├── game.js                 # Engine, input, combat, HUD, and basic stage
└── characters/
    ├── goku.js             # Goku stats, moves, states, boxes, and drawing
    └── vegeta.js           # Vegeta stats, moves, states, boxes, and drawing
```

## Controls

### Mobile
- D-pad: move, jump, crouch
- G: guard
- X: light punch
- Y: heavy punch
- Z: ki blast
- A: light kick
- B: heavy kick
- C: beam special (requires 500 power)

### Keyboard
- Arrow keys: move/jump/crouch
- Left Shift: guard
- J/K/L: X/Y/Z
- U/I/O: A/B/C

## GitHub Pages

Keep `index.html` and `game.js` in the repository root. Keep character files inside the `characters` folder. GitHub Pages should publish from `main` and `/(root)`.
