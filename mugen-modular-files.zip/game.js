import { goku } from './characters/goku.js';
import { vegeta } from './characters/vegeta.js';

const canvas=document.querySelector('#game');
const ctx=canvas.getContext('2d');
ctx.imageSmoothingEnabled=false;
const overlay=document.querySelector('#overlay');
const startBtn=document.querySelector('#start');
const restartBtn=document.querySelector('#restart');

const WORLD={w:640,h:360,floor:304,left:24,right:616,gravity:.43};
const FIXED=1000/60;

class Input {
  constructor(){this.held=new Set();this.pressed=new Set();this.history=[];this.bind();}
  press(k){if(!this.held.has(k))this.pressed.add(k);this.held.add(k);this.history.push({k,t:performance.now()});if(this.history.length>30)this.history.shift();}
  release(k){this.held.delete(k);}
  consume(k){const v=this.pressed.has(k);this.pressed.delete(k);return v;}
  clear(){this.held.clear();this.pressed.clear();}
  bind(){
    const key={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down',KeyJ:'x',KeyK:'y',KeyL:'z',KeyU:'a',KeyI:'b',KeyO:'c',ShiftLeft:'guard'};
    addEventListener('keydown',e=>{const k=key[e.code];if(!k)return;e.preventDefault();if(!e.repeat)this.press(k);},{passive:false});
    addEventListener('keyup',e=>{const k=key[e.code];if(!k)return;e.preventDefault();this.release(k);},{passive:false});
    document.querySelectorAll('[data-input]').forEach(btn=>{
      const k=btn.dataset.input;
      const down=e=>{e.preventDefault();this.press(k);btn.classList.add('active');btn.setPointerCapture?.(e.pointerId);};
      const up=e=>{e.preventDefault();this.release(k);btn.classList.remove('active');};
      btn.addEventListener('pointerdown',down,{passive:false});
      btn.addEventListener('pointerup',up,{passive:false});
      btn.addEventListener('pointercancel',up,{passive:false});
      btn.addEventListener('lostpointercapture',up,{passive:false});
      btn.addEventListener('contextmenu',e=>e.preventDefault());
    });
    addEventListener('blur',()=>this.clear());
  }
}

class Fighter {
  constructor(def,x,cpu=false){this.def=def;this.startX=x;this.cpu=cpu;this.reset();}
  reset(){this.x=this.startX;this.y=WORLD.floor;this.vx=0;this.vy=0;this.life=this.def.stats.life;this.power=0;this.facing=this.cpu?-1:1;this.state=0;this.anim='idle';this.animTick=0;this.frame=0;this.ctrl=true;this.move=null;this.hitstun=0;this.guardstun=0;this.onGround=true;this.guarding=false;this.crouching=false;this.hitOnce=false;this.combo=0;this.comboTimer=0;}
  setState(n,anim,ctrl=false){this.state=n;this.anim=anim;this.animTick=0;this.frame=0;this.ctrl=ctrl;this.hitOnce=false;}
  startMove(key){const m=this.def.moves[key];if(!m||!this.ctrl)return false;if(m.powerCost&&this.power<m.powerCost)return false;if(m.powerCost)this.power-=m.powerCost;this.move=m;this.setState(m.state,m.anim,false);return true;}
  command(input,opp){
    if(!this.ctrl||this.hitstun||this.guardstun)return;
    this.guarding=input.held.has('guard');
    this.crouching=input.held.has('down')&&this.onGround;
    if(this.guarding){this.setState(120,'guard',true);this.vx=0;return;}
    for(const k of ['c','z','y','b','x','a'])if(input.consume(k)&&this.startMove(k))return;
    if(input.consume('up')&&this.onGround){this.vy=this.def.stats.jump;this.onGround=false;this.setState(40,'jump',true);return;}
    const dir=(input.held.has('right')?1:0)-(input.held.has('left')?1:0);
    if(this.crouching){this.setState(11,'crouch',true);this.vx=0;return;}
    if(dir&&this.onGround){this.setState(20,'walk',true);this.vx=dir*(dir===this.facing?this.def.stats.walk:this.def.stats.backWalk);}
    else if(this.onGround){this.setState(0,'idle',true);this.vx*=.75;}
  }
  cpuCommand(opp){
    const fake={held:new Set(),pressed:new Set(),consume(k){const y=this.pressed.has(k);this.pressed.delete(k);return y;}};
    const d=Math.abs(opp.x-this.x),toward=opp.x>this.x?'right':'left';
    if(this.hitstun||this.guardstun)return fake;
    if(opp.move&&d<90&&Math.random()<.55)fake.held.add('guard');
    else if(d>145)fake.held.add(toward);
    else if(this.ctrl&&Math.random()<.055)fake.pressed.add(['x','y','a','b','z','c'][Math.floor(Math.random()*6)]);
    return fake;
  }
  update(input,opp){
    this.comboTimer=Math.max(0,this.comboTimer-1);if(!this.comboTimer)this.combo=0;
    if(this.hitstun>0){this.hitstun--;this.ctrl=false;} else if(this.guardstun>0){this.guardstun--;this.ctrl=false;} else if(!this.move)this.ctrl=true;
    if(this.move){
      this.animTick++;
      const m=this.move;
      if(m.projectile&&this.animTick===m.startup)spawnProjectile(this,m);
      if(this.animTick>=m.startup+m.active+m.recovery){this.move=null;this.setState(this.onGround?0:50,this.onGround?'idle':'fall',true);}
    } else {
      const cmd=this.cpu?this.cpuCommand(opp):input;this.command(cmd,opp);
      if(this.anim==='idle'||this.anim==='walk')this.animTick++;
    }
    if(!this.onGround){this.vy+=this.def.stats.gravity;this.y+=this.vy;if(this.vy>0&&this.state===40)this.setState(50,'fall',true);}
    this.x+=this.vx;
    if(this.y>=WORLD.floor){this.y=WORLD.floor;this.vy=0;this.onGround=true;if(this.state===40||this.state===50)this.setState(0,'idle',true);}else this.onGround=false;
    this.vx*=this.onGround?.82:.98;
    this.x=Math.max(WORLD.left,Math.min(WORLD.right,this.x));
    if(!this.move&&!this.hitstun&&!this.guardstun)this.facing=opp.x>=this.x?1:-1;
    this.updateFrame();
  }
  updateFrame(){
    const seq=this.def.animations[this.anim]||[1];let t=this.animTick,total=0;for(let i=0;i<seq.length;i++){total+=seq[i];if(t<total){this.frame=i;return;}}this.frame=seq.length-1;
  }
  hurtboxes(){return this.crouching?this.def.boxes.crouchHurt:this.def.boxes.standHurt;}
  attackBoxes(){if(!this.move||this.hitOnce)return[];const arr=this.def.boxes[this.move.anim]||[];return arr.filter(b=>b.frame===this.frame);}
  receive(attacker,move){
    const inFront=(attacker.x-this.x)*this.facing>0;
    if(this.guarding&&inFront&&this.onGround){this.life=Math.max(0,this.life-move.guardDamage);this.guardstun=move.guardstun;this.vx=attacker.facing*move.push*.35;return true;}
    this.life=Math.max(0,this.life-move.damage);this.hitstun=move.hitstun;this.vx=attacker.facing*move.push;this.vy=move.launch||0;if(this.vy<0)this.onGround=false;this.setState(this.life?5000:5100,this.life?'hit':'ko',false);this.power=Math.min(1000,this.power+90);return false;
  }
  draw(){this.def.draw(ctx,this,this.frame);}
}

const input=new Input();
const p1=new Fighter(goku,160,false);
const p2=new Fighter(vegeta,480,true);
const projectiles=[];const sparks=[];
let running=false,last=0,acc=0,shake=0,banner='';

function boxWorld(f,b){return{x:f.x+(f.facing>0?b.x:-b.x-b.w),y:f.y+b.y,w:b.w,h:b.h};}
function overlap(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
function resolveMelee(a,b){
  if(!a.move||a.hitOnce)return;
  for(const hb of a.attackBoxes())for(const hu of b.hurtboxes()){
    if(overlap(boxWorld(a,hb),boxWorld(b,hu))){a.hitOnce=true;const blocked=b.receive(a,a.move);if(!blocked){a.combo++;a.comboTimer=70;a.power=Math.min(1000,a.power+75);}spark(b.x,b.y-45,a.def.palette.energy);shake=blocked?2:5;return;}
  }
}
function bodyPush(){const d=Math.abs(p1.x-p2.x);if(d>=28)return;const push=(28-d)/2;if(p1.x<p2.x){p1.x-=push;p2.x+=push}else{p1.x+=push;p2.x-=push;}}
function spawnProjectile(owner,move){projectiles.push({owner,move,x:owner.x+owner.facing*24,y:owner.y-48,vx:owner.facing*(move.beam?7.5:5.2),life:move.beam?45:100,r:move.beam?10:5,color:owner.def.palette.energy,hit:false});}
function updateProjectiles(){for(let i=projectiles.length-1;i>=0;i--){const p=projectiles[i],target=p.owner===p1?p2:p1;p.x+=p.vx;p.life--;const box={x:p.x-p.r,y:p.y-p.r,w:p.r*(p.move.beam?6:2),h:p.r*2};let hit=false;for(const hu of target.hurtboxes())if(overlap(box,boxWorld(target,hu))){const blocked=target.receive(p.owner,p.move);if(!blocked){p.owner.combo++;p.owner.comboTimer=70;}spark(p.x,p.y,p.color,20);shake=p.move.beam?9:4;hit=true;break;}if(hit||p.life<=0||p.x<-80||p.x>720)projectiles.splice(i,1);}}
function spark(x,y,color,count=12){for(let i=0;i<count;i++){const a=Math.random()*Math.PI*2,s=1+Math.random()*4;sparks.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:12+Math.random()*12,color});}}
function updateSparks(){for(let i=sparks.length-1;i>=0;i--){const s=sparks[i];s.x+=s.vx;s.y+=s.vy;s.vy+=.12;s.life--;if(s.life<=0)sparks.splice(i,1);}}
function step(){if(!running)return;p1.update(input,p2);p2.update(input,p1);bodyPush();resolveMelee(p1,p2);resolveMelee(p2,p1);updateProjectiles();updateSparks();shake*=.8;if(p1.life<=0||p2.life<=0){running=false;banner=p1.life<=0?'VEGETA WINS':'GOKU WINS';}}

function drawStage(){
  ctx.fillStyle='#89b6d7';ctx.fillRect(0,0,640,360);
  ctx.fillStyle='#e9d79a';ctx.fillRect(0,180,640,124);
  ctx.fillStyle='#b58a58';ctx.beginPath();ctx.moveTo(0,240);ctx.lineTo(85,150);ctx.lineTo(160,225);ctx.lineTo(235,135);ctx.lineTo(330,230);ctx.lineTo(420,145);ctx.lineTo(510,230);ctx.lineTo(590,160);ctx.lineTo(640,220);ctx.lineTo(640,304);ctx.lineTo(0,304);ctx.fill();
  ctx.fillStyle='#7b5537';ctx.fillRect(0,304,640,56);ctx.fillStyle='#9b714c';for(let i=0;i<18;i++)ctx.fillRect((i*47)%640,315+(i%4)*9,20,4);
}
function drawHUD(){
  const lifeW=220;ctx.fillStyle='#111';ctx.fillRect(18,16,lifeW+4,18);ctx.fillRect(398,16,lifeW+4,18);ctx.fillStyle='#2d3140';ctx.fillRect(20,18,lifeW,14);ctx.fillRect(400,18,lifeW,14);
  ctx.fillStyle='#f08a24';ctx.fillRect(20,18,lifeW*(p1.life/1000),14);ctx.fillStyle='#2745d9';const w2=lifeW*(p2.life/1000);ctx.fillRect(620-w2,18,w2,14);
  ctx.fillStyle='#fff';ctx.font='bold 12px monospace';ctx.textAlign='left';ctx.fillText(p1.def.name,20,12);ctx.textAlign='right';ctx.fillText(p2.def.name,620,12);ctx.textAlign='center';ctx.fillText('∞',320,30);
  ctx.fillStyle='#151821';ctx.fillRect(20,39,150,7);ctx.fillRect(470,39,150,7);ctx.fillStyle=p1.def.palette.energy;ctx.fillRect(20,39,150*(p1.power/1000),7);ctx.fillStyle=p2.def.palette.energy;const pw=150*(p2.power/1000);ctx.fillRect(620-pw,39,pw,7);
  if(p1.combo>1){ctx.textAlign='left';ctx.fillStyle='#fff';ctx.fillText(`${p1.combo} HIT`,30,78);}if(p2.combo>1){ctx.textAlign='right';ctx.fillStyle='#fff';ctx.fillText(`${p2.combo} HIT`,610,78);}
  if(banner){ctx.textAlign='center';ctx.font='bold 28px monospace';ctx.fillStyle='#fff';ctx.fillText(banner,320,120);}
}
function draw(){ctx.save();if(shake>1)ctx.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);drawStage();for(const p of projectiles){ctx.fillStyle=p.color;ctx.fillRect(Math.round(p.x-p.r),Math.round(p.y-p.r),p.r*(p.move.beam?6:2),p.r*2);ctx.fillStyle='#fff';ctx.fillRect(Math.round(p.x-p.r/2),Math.round(p.y-p.r/2),p.r*(p.move.beam?5:1),p.r);}
p1.draw();p2.draw();for(const s of sparks){ctx.globalAlpha=Math.max(0,s.life/24);ctx.fillStyle=s.color;ctx.fillRect(s.x,s.y,2,2);}ctx.globalAlpha=1;drawHUD();ctx.restore();}
function loop(now){if(!last)last=now;acc+=Math.min(100,now-last);last=now;while(acc>=FIXED){step();acc-=FIXED;}draw();requestAnimationFrame(loop);}
function reset(){p1.reset();p2.reset();projectiles.length=0;sparks.length=0;banner='';running=true;overlay.classList.add('hidden');input.clear();}
startBtn.addEventListener('click',reset);restartBtn.addEventListener('click',reset);requestAnimationFrame(loop);
